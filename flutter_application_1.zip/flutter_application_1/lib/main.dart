import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? Key}) : super(key: key);

  @override
  Widget build(buildcontent context) {
    return MaterialApp(
      title: "Aplikasi Flutter Pertama",
      home: Scaffold(
        appBar: AppBar(
          title: "Aplikasi Flutter Pertama",
        ),
        body: const Center(
          child: Text("Hello World"),
        ),
      ),
    );
  }
}